package com.liskovsoft.browser;

import android.content.Context;
import android.util.AttributeSet;

public class NavigationBarPhone extends NavigationBarBase {
    public NavigationBarPhone(Context context) {
        super(context);
    }

    public NavigationBarPhone(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public NavigationBarPhone(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
