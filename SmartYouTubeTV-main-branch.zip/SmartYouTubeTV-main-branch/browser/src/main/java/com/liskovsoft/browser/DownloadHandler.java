package com.liskovsoft.browser;

import android.app.Activity;

/**
 * TODO: not implemented
 */
public class DownloadHandler {
    public static void onDownloadStartNoStream(Activity activity, String url, String userAgentString, Object o, Object o1, Object o2, boolean privateBrowsingEnabled) {

    }
}
