package com.liskovsoft.browser.xwalk;

public class XWalkInitCompleted {
}
