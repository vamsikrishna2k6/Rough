package com.liskovsoft.browser.addons;

import androidx.fragment.app.Fragment;
import com.liskovsoft.browser.BaseUi;

public class SimpleUi extends BaseUi {
    public SimpleUi(Fragment browser, SimpleUIController controller) {
        super(browser, controller);
    }
}
