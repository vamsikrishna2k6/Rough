package com.liskovsoft.smartyoutubetv.fragments;

import android.content.Intent;

public interface PlayerListener {
    void onPlayerAction(Intent intent);
    void openExternalPlayer(Intent intent);
}
