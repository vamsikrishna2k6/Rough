package com.liskovsoft.smartyoutubetv.flavors.common;

import androidx.appcompat.app.AppCompatActivity;

public abstract class CrashHandlerActivity extends AppCompatActivity {
}
